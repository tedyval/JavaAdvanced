package Generics2;

import java.util.ArrayList;
import java.util.List;

public class Box<T> {
    private List<T> list;

    public Box(){
        this.list = new ArrayList<>();
    }

    public void addElement(T element){
        this.list.add(element);
    }

    public  void swapElements(int firstIndex, int secondIndex){
      T temp = this.list.get(firstIndex);
      list.set(firstIndex,list.get(secondIndex));
      list.set(secondIndex,temp);
    }

    @Override
    public String toString(){
        StringBuilder str = new StringBuilder();
        for (T t : list) {
            str.append(t.getClass().getName()).append(": ").append(t).append(System.lineSeparator());
        }
        return  str.toString();


    }



}

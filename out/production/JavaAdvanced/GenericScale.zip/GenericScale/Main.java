package GenericScale;

public class Main {
    public static void main(String[] args) {

    Scale<String> stringScale = new Scale<>("4","6");
        System.out.println(stringScale.getHeavier());




    }


}
